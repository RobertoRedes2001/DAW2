<?php 

namespace Roberto\App\model;

class claseA{
    public function mostrar(){
        echo "Estoy en la clase A.";
    }
}

?>