<?php 

namespace Roberto\App\pepito;

class claseB{
    public function mostrar(){
        echo "Estoy en la clase B.";
    }
}

?>