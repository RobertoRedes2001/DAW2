<?php

namespace App\Core\Interfaces;

interface IRoutes{
    public function getRoutes();
}