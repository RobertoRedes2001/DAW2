<?php

namespace App\Core\Interfaces;

interface ISession{
    public function setTemplateEngineAvailable(&$templateEnvironment);
}