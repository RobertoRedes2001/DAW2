<?php
class sayingView {
    
    # Método público llamado "readSaying" que acepta un parámetro $saying.
    public function readSaying($saying){
        # Imprime un refran.
        echo $saying;
    }
    
}
?>